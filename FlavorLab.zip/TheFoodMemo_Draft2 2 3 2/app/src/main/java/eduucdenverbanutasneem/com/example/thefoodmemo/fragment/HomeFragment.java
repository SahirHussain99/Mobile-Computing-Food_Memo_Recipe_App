package eduucdenverbanutasneem.com.example.thefoodmemo.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import eduucdenverbanutasneem.com.example.thefoodmemo.AllRecipesActivity;
import eduucdenverbanutasneem.com.example.thefoodmemo.adapters.HorizontalRecipeAdapter;
import eduucdenverbanutasneem.com.example.thefoodmemo.adapters.RecipeAdapter;

import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.FragmentHomeBinding;
import eduucdenverbanutasneem.com.example.thefoodmemo.models.Recipe;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        loadRecipes();
         binding.etSearch.setOnEditorActionListener((TextView, i , KeyEvent) -> {
             if(i == EditorInfo.IME_ACTION_SEARCH){
                 performsearch();
                 return true;
             }
             return  false; 
         });

         binding.tvSeeAllFav.setOnClickListener(v -> {
             Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
             intent.putExtra("type", "favourite");
             startActivity(intent);
         });

        binding.tvSeeAllPop.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
            intent.putExtra("type", "popular");
            startActivity(intent);
        });

    }

    private void performsearch() {
        String query = Objects.requireNonNull(binding.etSearch.getText()).toString().trim();
        Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
        intent.putExtra("type", "search");
        intent.putExtra("query" , query);
        startActivity(intent);
    }

    private void loadRecipes() {
        binding.rvPopulars.setAdapter(new HorizontalRecipeAdapter());
        binding.rvFavoriteRecipe.setAdapter(new HorizontalRecipeAdapter());
        DatabaseReference  reference = FirebaseDatabase.getInstance().getReference("Recipes");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Recipe> recipes = new ArrayList<>();
                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Recipe recipe = dataSnapshot.getValue(Recipe.class);
                    String recipeId = dataSnapshot.getKey();
                    recipe.setId(recipeId);
                    recipes.add(recipe);
                }
                loadPopularRecipes(recipes);
                loadFavoriteRecipes(recipes);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Error",error.getMessage());
            }
        });
    }
    private void loadPopularRecipes(List<Recipe> recipes) {
        List<Recipe> popularRecipes = new ArrayList<>();
        for(int i = 0 ; i< 5 ; i++){
            int random = (int) (Math.random() * recipes.size());
            popularRecipes.add(recipes.get(random));
        }
        HorizontalRecipeAdapter adapter = (HorizontalRecipeAdapter) binding.rvPopulars.getAdapter();
        if (adapter != null) {
            adapter.setRecipeList(popularRecipes);
        }
    }
    private void loadFavoriteRecipes(List<Recipe> recipes){
        List<Recipe> favoriteRecipes = new ArrayList<>();
        for(int i = 0 ; i< 5 ; i++){
            int random = (int) (Math.random() * recipes.size());
            favoriteRecipes.add(recipes.get(random));
        }
        HorizontalRecipeAdapter adapter = (HorizontalRecipeAdapter) binding.rvFavoriteRecipe.getAdapter();
        if (adapter != null) {
            adapter.setRecipeList(favoriteRecipes);
           }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}