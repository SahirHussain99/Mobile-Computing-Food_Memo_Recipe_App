package eduucdenverbanutasneem.com.example.thefoodmemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.FirebaseApp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    @NonNull ActivityLoginBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //databaseHelper = new DatabaseHelper(this);

        binding.tvSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);

            }
        });
    }


    public void gotomain(View view) {
        String email = binding.etEmail.getText().toString();
        String password = binding.etPassword.getText().toString();

        if(email.equals("" )|| password.equals("")){
            Toast.makeText(LoginActivity.this,"All Fields are Required",Toast.LENGTH_LONG).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(LoginActivity.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
        } else if (password.length() < 6) {
            Toast.makeText(LoginActivity.this, "Password must be atleast 6 characters long", Toast.LENGTH_SHORT).show();

        } else
        {
            FirebaseApp.initializeApp(this);
            FirebaseAuth auth = FirebaseAuth.getInstance();
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(
                    task -> {
                        if(task.isSuccessful()){
                            Toast.makeText(this, "Login Successfull",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(LoginActivity.this,MainActivity.class));
                            finish();
                        }
                        else {
                            Toast.makeText(this, "Login Failed , Create Account ",Toast.LENGTH_LONG).show();
                        }
                    });
        }
    }
}

