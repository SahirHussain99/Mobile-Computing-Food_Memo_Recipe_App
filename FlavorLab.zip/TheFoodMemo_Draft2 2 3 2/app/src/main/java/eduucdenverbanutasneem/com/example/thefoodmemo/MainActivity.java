package eduucdenverbanutasneem.com.example.thefoodmemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize the toolbar
        toolbar = findViewById(R.id.myToolBar);
        setSupportActionBar(toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupWithNavController(binding.navView, navController);
        binding.floatingActionButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this , AddRecipeActivity.class)));
    }

    //sahir
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu resource to display the items in the app bar
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_log_out) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void logout() {
        Intent intent = new Intent(MainActivity.this , LoginActivity.class);
        startActivity(intent);
        Toast.makeText(this, "You have been successfully logged out", Toast.LENGTH_SHORT).show();
    }
}

