package eduucdenverbanutasneem.com.example.thefoodmemo;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.ActivityRegisterBinding;


public class RegisterActivity extends AppCompatActivity {

    ActivityRegisterBinding binding;
    DatabaseHelper databaseHelper;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        databaseHelper  = new DatabaseHelper(this);

        binding.buttonReg.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                String email = binding.etEmailReg.getText().toString();
                String password  = binding.etPasswordReg.getText().toString();

                if(email.equals("" )|| password.equals(""))
                    Toast.makeText(RegisterActivity.this, "All Fields are Required", Toast.LENGTH_LONG).show();
                else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    Toast.makeText(RegisterActivity.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                }
                else if (password.length() < 6)
                {
                    Toast.makeText(RegisterActivity.this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
                }
                else {createnewuser(email,password);}
            }
        });


    }

    private void createnewuser(String email, String password) {
        FirebaseApp.initializeApp(this);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                Toast.makeText(RegisterActivity.this , "SUCCESSFULLY ACCOUNT CREATED ",Toast.LENGTH_LONG).show();
                finish();}
            else {
                Toast.makeText(RegisterActivity.this, " ACCOUNT CREATION FAILED ", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void gotologin(View view) {
        Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
        startActivity(intent);
    }
}