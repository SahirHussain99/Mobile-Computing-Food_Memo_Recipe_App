package eduucdenverbanutasneem.com.example.thefoodmemo;

public class ActivityRegisterBinding {
}
