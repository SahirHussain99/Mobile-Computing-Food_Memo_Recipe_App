package eduucdenverbanutasneem.com.example.thefoodmemo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.ActivitySplashBinding;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {
    private int splashScreenTime = 3000; //3 seconds
    private int timeInterval = 100; //0.1 seconds
    private int progress = 0; //0 to 100 for progress bar
    private Runnable runnable;
    private Handler handler;

    private ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());//View binding for Splash Screen
        setContentView(binding.getRoot());
        binding.progressBar.setMax(splashScreenTime);//set max value for progress bar
        binding.progressBar.setProgress(progress);// set initial value for progress bar
        handler = new Handler(Looper.getMainLooper());//create handler
        runnable = () -> {
            //code to check if loading time completed or not
            if (progress < splashScreenTime){
                progress += timeInterval;
                binding.progressBar.setProgress(progress);
                handler.postDelayed(runnable, timeInterval);
            } else {
                Toast.makeText(SplashActivity.this, "Loading Completed", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                finish();
            }
        };
        handler.postDelayed(runnable, timeInterval); //start handler
    }
}