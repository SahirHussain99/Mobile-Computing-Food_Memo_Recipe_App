package eduucdenverbanutasneem.com.example.thefoodmemo.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eduucdenverbanutasneem.com.example.thefoodmemo.adapters.CategoryAdapter;
import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.FragmentCategoryBinding;
import eduucdenverbanutasneem.com.example.thefoodmemo.models.Category;

public class CategoriesFragment extends Fragment {

    private FragmentCategoryBinding binding;
    private CategoryAdapter categoryAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentCategoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        categoryAdapter = new CategoryAdapter();
        binding.rvCategories.setAdapter(categoryAdapter);
        loadCategories();
    }

    private void loadCategories() {
        //binding.rvCategories.setAdapter(new CategoryAdapter());
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Categories");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Category> categories = new ArrayList<>();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Category category = dataSnapshot.getValue(Category.class);
                    categories.add(category);
                }
                categoryAdapter.setCategoryList(categories);
                //if(binding.rvCategories.getAdapter() != null)

                    CategoryAdapter adapter = (CategoryAdapter) binding.rvCategories.getAdapter();
                    if (adapter != null)
                    {
                        adapter.setCategoryList(categories);
                    }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Error", error.getMessage());
            }
        });
    }
        @Override
        public void onDestroyView( )
        {
            super.onDestroyView();
            binding = null;
        }
    }