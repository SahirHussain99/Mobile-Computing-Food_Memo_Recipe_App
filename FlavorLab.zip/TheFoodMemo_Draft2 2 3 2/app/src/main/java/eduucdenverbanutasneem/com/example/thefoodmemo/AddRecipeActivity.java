
package eduucdenverbanutasneem.com.example.thefoodmemo;

import static java.lang.System.currentTimeMillis;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import eduucdenverbanutasneem.com.example.thefoodmemo.databinding.ActivityAddRecipeBinding;
import eduucdenverbanutasneem.com.example.thefoodmemo.models.Category;
import eduucdenverbanutasneem.com.example.thefoodmemo.models.Recipe;

public class    AddRecipeActivity extends AppCompatActivity {

    ActivityAddRecipeBinding binding;
    private boolean isImageSelected = false ;
    private ProgressDialog dialog;
    boolean isEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddRecipeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        String recipeId = getIntent().getStringExtra("recipeId");

        if (recipeId != null) {
            // If the recipeId is not null, fetch the recipe from Firebase and populate the UI
            retrieveRecipeData(recipeId);
        } else {
            // If recipeId is null, it means we are adding a new recipe, so set up the UI accordingly
            // (your existing setup code here)
        }
        LoadCategories();

        binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getdata();
            }
        });

        binding.imgRecipe.setOnClickListener(v -> {pickImage();});

        isEdit = getIntent().getBooleanExtra("isEdit",false);
        }

    private void retrieveRecipeData(String recipeId) {
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Recipes");
            reference.child(recipeId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Recipe recipe = snapshot.getValue(Recipe.class);
                    if (recipe != null) {
                        // Populate the UI components with the retrieved data
                        binding.etRecipeName.setText(recipe.getName());
                        binding.etCalories.setText(String.valueOf(recipe.getCalories()));
                        binding.etCategory.setText(recipe.getCategory());
                        binding.etDescription.setText(recipe.getDescription());
                        Glide
                                .with(AddRecipeActivity.this)
                                .load(recipe.getImageUrl())
                                .centerCrop()
                                .placeholder(R.mipmap.ic_launcher)
                                .into(binding.imgRecipe);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e("AddRecipeActivity", "Database error: " + error.getMessage());
                }
            });

    }

    private void pickImage() {

        PickImageDialog.build(new PickSetup()).show(AddRecipeActivity.this).setOnPickResult(r -> {
            Log.e("ProfileFragment","OnPickResult: " + r.getUri());
            binding.imgRecipe.setImageBitmap(r.getBitmap());
            binding.imgRecipe.setScaleType(ImageView.ScaleType.CENTER_CROP);
            isImageSelected = true;
        }).setOnPickCancel(() -> Toast.makeText(AddRecipeActivity.this,"Cancelled",Toast.LENGTH_LONG).show());

    }

    private void getdata() {
        String recipename = Objects.requireNonNull(binding.etRecipeName.getText()).toString();
        String recipedescription = Objects.requireNonNull(binding.etDescription.getText()).toString();
        String cookingtime = Objects.requireNonNull(binding.etCookingTime.getText()).toString();
        String recipecategory = binding.etCategory.getText().toString();
        String calories = Objects.requireNonNull(binding.etCalories.getText()).toString();


        if(recipename.isEmpty()){
            binding.etRecipeName.setError("Recipe name can't be empty, Enter Valid name");
        }else if (recipedescription.isEmpty()) {
            binding.etDescription.setError("Description can't be empty , Enter valid description");
        }else if (cookingtime.isEmpty()) {
            binding.etCookingTime.setError("Cooking time can't be empty , Enter valid time");
        }else if (recipecategory.isEmpty()) {
            binding.etCategory.setError("Select category for the recipe");
        }else if (calories.isEmpty()) {
            binding.etCalories.setError("calories can't be empty , Enter valid calories count");
        } else if (!isImageSelected) {
            Toast.makeText(this, "Select an image", Toast.LENGTH_SHORT).show();
        } else {
            dialog = new ProgressDialog(this);
            dialog.setMessage("Uploading Recipe Details.....");
            dialog.setCancelable(false);
            dialog.show();
            Recipe recipe = new Recipe(FirebaseAuth.getInstance().getUid(), calories, recipecategory , recipedescription ,"" , recipename , cookingtime);
            uploadImage(recipe);
        }
    }

    private String uploadImage(Recipe recipe) {

        final String[] url = {""};
        binding.imgRecipe.setDrawingCacheEnabled(true);
        Bitmap bitmap = ((BitmapDrawable)binding.imgRecipe.getDrawable()).getBitmap();
        binding.imgRecipe.setDrawingCacheEnabled(false);
        String id = isEdit ? recipe.getId() : currentTimeMillis() + "";
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference().child("images/" + id  +  "_recipe.jpg");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();
        UploadTask uploadTask = storageRef.putBytes(data);
        uploadTask.continueWithTask(task -> {
            if (!task.isSuccessful()) {
                throw Objects.requireNonNull(task.getException());
            }
            return storageRef.getDownloadUrl();
        }).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                Uri downloadUri = task.getResult();
                url[0] = downloadUri.toString();
                Toast.makeText(AddRecipeActivity.this,"Image Upload successfully ", Toast.LENGTH_LONG).show();
                saveDataInfirebase(recipe,url[0]);
            }
            else{
                Toast.makeText(AddRecipeActivity.this, "Error in Upload image", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                Log.e("ProfileFragment", "onComplete:" + Objects.requireNonNull(task.getException()));
            }
        });
        return url[0];
    }

    private void saveDataInfirebase(Recipe recipe, String url) {
        recipe.setImage(url);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Recipes");
        String id = reference.push().getKey();
        if (id != null) {
            reference.child(id).setValue(recipe).addOnCompleteListener(task ->{
                if(task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(AddRecipeActivity.this, "Recipe Added", Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    dialog.dismiss();
                    Toast.makeText(AddRecipeActivity.this, "Error in adding Recipe", Toast.LENGTH_SHORT).show();
                }
            });

        }
        else {
            dialog.dismiss();
            Toast.makeText(AddRecipeActivity.this, "Error: Recipe ID is null", Toast.LENGTH_SHORT).show();
        }
            recipe.setImage(url);
        }


    private void LoadCategories() {
        List<String> categories= new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,categories);
        binding.etCategory.setAdapter(adapter);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Categories");
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists() && snapshot.hasChildren()){
                    for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                        categories.add(dataSnapshot.getValue(Category.class).getName());
                    }
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }



}